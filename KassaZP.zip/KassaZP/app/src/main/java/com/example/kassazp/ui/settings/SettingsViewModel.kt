package com.example.kassazp.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kassazp.data.AppSettings
import com.example.kassazp.data.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: SettingsRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(AppSettings())
    val uiState: StateFlow<AppSettings> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.settingsFlow.collect { _uiState.value = it }
        }
    }

    fun updateDayPercent(value: Double) = persist(_uiState.value.copy(dayPercent = value))
    fun updateNightPercent(value: Double) = persist(_uiState.value.copy(nightPercent = value))
    fun updatePdPercent(value: Double) = persist(_uiState.value.copy(pdPercent = value))
    fun updateWeldPercent(value: Double) = persist(_uiState.value.copy(weldPercent = value))
    fun updatePinEnabled(enabled: Boolean) = persist(_uiState.value.copy(pinEnabled = enabled))
    fun updatePin(pin: String) = persist(_uiState.value.copy(pin = pin))

    fun resetToDefaults() {
        viewModelScope.launch { repository.resetToDefaults() }
    }

    private fun persist(newSettings: AppSettings) {
        _uiState.value = newSettings
        viewModelScope.launch { repository.update(newSettings) }
    }
}
