package com.example.kassazp.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val settings by viewModel.uiState.collectAsState()

    var dayText by remember(settings.dayPercent) { mutableStateOf(formatPercent(settings.dayPercent)) }
    var nightText by remember(settings.nightPercent) { mutableStateOf(formatPercent(settings.nightPercent)) }
    var pdText by remember(settings.pdPercent) { mutableStateOf(formatPercent(settings.pdPercent)) }
    var weldText by remember(settings.weldPercent) { mutableStateOf(formatPercent(settings.weldPercent)) }
    var pinText by remember(settings.pin) { mutableStateOf(settings.pin) }
    var showResetConfirm by remember { mutableStateOf(false) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Настройки", style = MaterialTheme.typography.headlineMedium)

            Text("Проценты расчёта", style = MaterialTheme.typography.titleMedium)

            PercentField(
                label = "День (%)",
                value = dayText,
                onValueChange = {
                    dayText = it
                    it.toDoubleOrNull()?.let { v -> viewModel.updateDayPercent(v) }
                }
            )
            PercentField(
                label = "Ночь (%)",
                value = nightText,
                onValueChange = {
                    nightText = it
                    it.toDoubleOrNull()?.let { v -> viewModel.updateNightPercent(v) }
                }
            )
            PercentField(
                label = "ПД (%)",
                value = pdText,
                onValueChange = {
                    pdText = it
                    it.toDoubleOrNull()?.let { v -> viewModel.updatePdPercent(v) }
                }
            )
            PercentField(
                label = "Сварка (%)",
                value = weldText,
                onValueChange = {
                    weldText = it
                    it.toDoubleOrNull()?.let { v -> viewModel.updateWeldPercent(v) }
                }
            )

            OutlinedButton(
                onClick = { showResetConfirm = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Сбросить к стандартным (27% / 35% / 30% / 30%)")
            }

            Divider()

            Text("Безопасность", style = MaterialTheme.typography.titleMedium)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("PIN-код при входе")
                Switch(
                    checked = settings.pinEnabled,
                    onCheckedChange = { viewModel.updatePinEnabled(it) }
                )
            }
            if (settings.pinEnabled) {
                OutlinedTextField(
                    value = pinText,
                    onValueChange = {
                        val filtered = it.filter { c -> c.isDigit() }.take(6)
                        pinText = filtered
                        viewModel.updatePin(filtered)
                    },
                    label = { Text("PIN (4-6 цифр)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Сбросить настройки?") },
            text = { Text("Проценты вернутся к значениям по умолчанию, PIN-код будет отключён.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.resetToDefaults()
                    showResetConfirm = false
                }) { Text("Сбросить") }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text("Отмена") }
            }
        )
    }
}

@Composable
private fun PercentField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.filter { c -> c.isDigit() || c == '.' }) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

private fun formatPercent(value: Double): String =
    if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()
