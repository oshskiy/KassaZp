package com.example.kassazp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlin.math.max

data class BarEntry(val label: String, val value: Double)

/**
 * Простая столбчатая диаграмма без сторонних библиотек — рисуется на Canvas,
 * чтобы не зависеть от версии внешней chart-библиотеки при сборке.
 */
@Composable
fun BarChart(entries: List<BarEntry>, modifier: Modifier = Modifier, barColor: Color = Color(0xFFFF7A00)) {
    val maxValue = max(entries.maxOfOrNull { it.value } ?: 0.0, 1.0)

    Column(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .padding(horizontal = 8.dp)
        ) {
            if (entries.isEmpty()) return@Canvas
            val barWidth = size.width / (entries.size * 1.6f)
            val gap = barWidth * 0.6f
            var x = gap / 2

            entries.forEach { entry ->
                val barHeight = (entry.value / maxValue * size.height).toFloat()
                drawRect(
                    color = barColor,
                    topLeft = Offset(x, size.height - barHeight),
                    size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                )
                x += barWidth + gap
            }
        }
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            entries.forEach { entry ->
                Text(
                    text = entry.label,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
