package com.example.kassazp.utils

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Простой генератор PDF через встроенный android.graphics.pdf.PdfDocument —
 * без сторонних библиотек, чтобы не рисковать проблемами сборки.
 */
object PdfExporter {

    private const val PAGE_WIDTH = 595 // A4 @ 72dpi
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 48f

    fun exportLines(context: Context, title: String, lines: List<String>, fileName: String): Uri {
        val document = PdfDocument()
        val titlePaint = Paint().apply { textSize = 18f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { textSize = 13f }
        val datePaint = Paint().apply { textSize = 10f; color = 0xFF666666.toInt() }

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas

        var y = MARGIN
        canvas.drawText(title, MARGIN, y, titlePaint)
        y += 20f
        val dateStr = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(java.util.Date())
        canvas.drawText(dateStr, MARGIN, y, datePaint)
        y += 30f

        for (line in lines) {
            if (y > PAGE_HEIGHT - MARGIN) {
                document.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = MARGIN
            }
            canvas.drawText(line, MARGIN, y, bodyPaint)
            y += 20f
        }
        document.finishPage(page)

        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, fileName)
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()

        return FileProvider.getUriForFile(context, "com.example.kassazp.fileprovider", file)
    }
}
