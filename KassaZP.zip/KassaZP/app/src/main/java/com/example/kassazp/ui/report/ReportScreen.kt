package com.example.kassazp.ui.report

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIos
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.kassazp.ui.components.BarChart
import com.example.kassazp.ui.components.BarEntry
import com.example.kassazp.ui.components.PieChart
import com.example.kassazp.ui.components.buildPieSlices
import com.example.kassazp.utils.CsvExporter
import com.example.kassazp.utils.CsvRow
import com.example.kassazp.utils.PdfExporter
import com.example.kassazp.utils.ShareUtils
import com.example.kassazp.utils.asRub
import com.example.kassazp.utils.asRubSigned
import java.util.Calendar

@Composable
fun ReportScreen(viewModel: ReportViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        if (!state.hasGenerated) viewModel.generateReport()
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollStateCompat())
        ) {
            Text("Отчёт", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))

            MonthSelector(
                year = state.year,
                month = state.month,
                onPrevious = {
                    val cal = Calendar.getInstance()
                    cal.set(state.year, state.month, 1)
                    cal.add(Calendar.MONTH, -1)
                    viewModel.setPeriod(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH))
                },
                onNext = {
                    val cal = Calendar.getInstance()
                    cal.set(state.year, state.month, 1)
                    cal.add(Calendar.MONTH, 1)
                    viewModel.setPeriod(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH))
                }
            )

            Spacer(Modifier.height(8.dp))
            Button(onClick = { viewModel.generateReport() }, modifier = Modifier.fillMaxWidth()) {
                Text("Сформировать отчёт")
            }
            Spacer(Modifier.height(16.dp))

            if (state.isLoading) {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (state.rows.isEmpty() && state.hasGenerated) {
                Text("За этот месяц данных нет.")
            } else if (state.rows.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Итого за месяц: ${state.totalForMonth.asRub()}", style = MaterialTheme.typography.titleMedium)
                        val pct = if (state.totalLastMonth > 0)
                            ((state.totalForMonth - state.totalLastMonth) / state.totalLastMonth * 100)
                        else 0.0
                        val comparisonText = when {
                            state.totalLastMonth <= 0 -> "Нет данных за прошлый месяц для сравнения"
                            pct >= 0 -> "Заработок вырос на ${"%.1f".format(pct)}%"
                            else -> "Заработок упал на ${"%.1f".format(-pct)}%"
                        }
                        Text(comparisonText, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(Modifier.height(12.dp))

                val medals = listOf("🥇", "🥈", "🥉")
                state.rows.forEachIndexed { index, row ->
                    val medal = medals.getOrNull(index) ?: "  "
                    val arrow = if (row.diffFromLastMonth >= 0) "🟢" else "🔴"
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("$medal ${row.name}", style = MaterialTheme.typography.bodyLarge)
                            Column(horizontalAlignment = Alignment.End) {
                                Text(row.total.asRub(), style = MaterialTheme.typography.titleMedium)
                                Text("$arrow ${row.diffFromLastMonth.asRubSigned()}", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("Заработок по работникам", style = MaterialTheme.typography.titleMedium)
                BarChart(
                    entries = state.rows.map { BarEntry(it.name.take(6), it.total) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(16.dp))
                Text("Доля в общем заработке", style = MaterialTheme.typography.titleMedium)
                PieChart(
                    slices = buildPieSlices(state.rows.map { it.name to it.total }),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val text = buildReportText(state)
                            ShareUtils.shareText(context, text)
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Текст") }

                    OutlinedButton(
                        onClick = {
                            val lines = buildReportLines(state)
                            val uri = PdfExporter.exportLines(
                                context,
                                "Отчёт за ${monthLabel(state.year, state.month)}",
                                lines,
                                "report_${state.year}_${state.month + 1}.pdf"
                            )
                            ShareUtils.shareFile(context, uri, "application/pdf")
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("PDF") }

                    OutlinedButton(
                        onClick = {
                            val csvRows = state.rows.map {
                                CsvRow(
                                    name = it.name,
                                    month = monthLabel(state.year, state.month),
                                    amount = it.total,
                                    day = it.dayTotal,
                                    night = it.nightTotal
                                )
                            }
                            val uri = CsvExporter.export(context, csvRows, "report_${state.year}_${state.month + 1}.csv")
                            ShareUtils.shareFile(context, uri, "text/csv")
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("CSV") }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MonthSelector(year: Int, month: Int, onPrevious: () -> Unit, onNext: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrevious) {
            Icon(Icons.Filled.ArrowBackIos, contentDescription = "Предыдущий месяц")
        }
        Text(monthLabel(year, month), style = MaterialTheme.typography.titleMedium)
        IconButton(onClick = onNext) {
            Icon(Icons.Filled.ArrowForwardIos, contentDescription = "Следующий месяц")
        }
    }
}

private fun buildReportText(state: ReportUiState): String {
    val sb = StringBuilder()
    sb.append("Отчёт за ${monthLabel(state.year, state.month)}\n\n")
    val medals = listOf("🥇", "🥈", "🥉")
    state.rows.forEachIndexed { index, row ->
        val medal = medals.getOrNull(index) ?: "  "
        val arrow = if (row.diffFromLastMonth >= 0) "🟢" else "🔴"
        sb.append("$medal ${row.name}: ${row.total.asRub()} $arrow ${row.diffFromLastMonth.asRubSigned()}\n")
    }
    sb.append("\nИтого: ${state.totalForMonth.asRub()}")
    return sb.toString()
}

private fun buildReportLines(state: ReportUiState): List<String> =
    buildReportText(state).split("\n")

@Composable
private fun rememberScrollStateCompat() = androidx.compose.foundation.rememberScrollState()
