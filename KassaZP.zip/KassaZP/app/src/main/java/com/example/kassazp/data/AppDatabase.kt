package com.example.kassazp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.kassazp.data.dao.EarningDao
import com.example.kassazp.data.dao.KassaDraftDao
import com.example.kassazp.data.dao.WorkerDao
import com.example.kassazp.data.entity.EarningEntity
import com.example.kassazp.data.entity.KassaDraftEntity
import com.example.kassazp.data.entity.WorkerEntity

@Database(
    entities = [WorkerEntity::class, EarningEntity::class, KassaDraftEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun workerDao(): WorkerDao
    abstract fun earningDao(): EarningDao
    abstract fun kassaDraftDao(): KassaDraftDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kassazp.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
