package com.example.kassazp.ui.report

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kassazp.data.dao.EarningDao
import com.example.kassazp.data.dao.WorkerDao
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

data class WorkerReportRow(
    val name: String,
    val total: Double,
    val dayTotal: Double,
    val nightTotal: Double,
    val diffFromLastMonth: Double
)

data class ReportUiState(
    val year: Int = Calendar.getInstance().get(Calendar.YEAR),
    val month: Int = Calendar.getInstance().get(Calendar.MONTH), // 0-based
    val rows: List<WorkerReportRow> = emptyList(),
    val totalForMonth: Double = 0.0,
    val totalLastMonth: Double = 0.0,
    val isLoading: Boolean = false,
    val hasGenerated: Boolean = false
)

private val MONTH_NAMES_RU = listOf(
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
)

fun monthLabel(year: Int, month: Int): String = "${MONTH_NAMES_RU[month]} $year"

class ReportViewModel(
    private val workerDao: WorkerDao,
    private val earningDao: EarningDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportUiState())
    val uiState: StateFlow<ReportUiState> = _uiState.asStateFlow()

    fun setPeriod(year: Int, month: Int) {
        _uiState.value = _uiState.value.copy(year = year, month = month, hasGenerated = false)
    }

    fun generateReport() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val year = _uiState.value.year
            val month = _uiState.value.month

            val (start, end) = monthRange(year, month)
            val (prevStart, prevEnd) = previousMonthRange(year, month)

            val workers = workerDao.observeAll()
            // Одноразовое считывание через first()
            val workerList = kotlinx.coroutines.flow.first(workers)
            val currentEarnings = earningDao.getForPeriod(start, end)
            val prevEarnings = earningDao.getForPeriod(prevStart, prevEnd)

            val rows = workerList.map { worker ->
                val entries = currentEarnings.filter { it.workerId == worker.id }
                val total = entries.sumOf { it.amount }
                val dayTotal = entries.filter { it.shift == "День" }.sumOf { it.amount }
                val nightTotal = entries.filter { it.shift == "Ночь" }.sumOf { it.amount }
                val prevTotal = prevEarnings.filter { it.workerId == worker.id }.sumOf { it.amount }
                WorkerReportRow(worker.name, total, dayTotal, nightTotal, total - prevTotal)
            }.filter { it.total > 0 }
                .sortedByDescending { it.total }

            _uiState.value = _uiState.value.copy(
                rows = rows,
                totalForMonth = rows.sumOf { it.total },
                totalLastMonth = prevEarnings.sumOf { it.amount },
                isLoading = false,
                hasGenerated = true
            )
        }
    }

    private fun monthRange(year: Int, month: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(year, month, 1, 0, 0, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        cal.add(Calendar.MILLISECOND, -1)
        val end = cal.timeInMillis
        return start to end
    }

    private fun previousMonthRange(year: Int, month: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(year, month, 1, 0, 0, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.MONTH, -1)
        val start = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        cal.add(Calendar.MILLISECOND, -1)
        val end = cal.timeInMillis
        return start to end
    }
}
