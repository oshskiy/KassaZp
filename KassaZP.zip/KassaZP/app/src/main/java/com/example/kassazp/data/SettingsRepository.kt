package com.example.kassazp.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "kassazp_settings")

data class AppSettings(
    val dayPercent: Double = 27.0,
    val nightPercent: Double = 35.0,
    val pdPercent: Double = 30.0,
    val weldPercent: Double = 30.0,
    val pinEnabled: Boolean = false,
    val pin: String = ""
)

/**
 * Настройки процентов и PIN-кода. Хранятся локально в DataStore (простой
 * ключ-значение), применяются к каждому новому расчёту кассы.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val DAY = doublePreferencesKey("day_percent")
        val NIGHT = doublePreferencesKey("night_percent")
        val PD = doublePreferencesKey("pd_percent")
        val WELD = doublePreferencesKey("weld_percent")
        val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val PIN = stringPreferencesKey("pin")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            dayPercent = prefs[Keys.DAY] ?: 27.0,
            nightPercent = prefs[Keys.NIGHT] ?: 35.0,
            pdPercent = prefs[Keys.PD] ?: 30.0,
            weldPercent = prefs[Keys.WELD] ?: 30.0,
            pinEnabled = prefs[Keys.PIN_ENABLED] ?: false,
            pin = prefs[Keys.PIN] ?: ""
        )
    }

    suspend fun update(settings: AppSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DAY] = settings.dayPercent
            prefs[Keys.NIGHT] = settings.nightPercent
            prefs[Keys.PD] = settings.pdPercent
            prefs[Keys.WELD] = settings.weldPercent
            prefs[Keys.PIN_ENABLED] = settings.pinEnabled
            prefs[Keys.PIN] = settings.pin
        }
    }

    suspend fun resetToDefaults() {
        update(AppSettings(pinEnabled = false, pin = ""))
    }
}
