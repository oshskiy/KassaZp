package com.example.kassazp.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Черновик экрана "Касса". Одна строка на всё приложение (id всегда 1) —
 * хранит несохранённый ввод, чтобы данные не терялись при закрытии приложения.
 * rowsJson — сериализованный список строк ввода (сумма + тип), простой
 * формат "сумма:тип;сумма:тип" чтобы не тащить лишнюю библиотеку JSON.
 */
@Entity(tableName = "kassa_draft")
data class KassaDraftEntity(
    @PrimaryKey val id: Int = 1,
    val shift: String = "День",
    val rowsSerialized: String = ""
)
