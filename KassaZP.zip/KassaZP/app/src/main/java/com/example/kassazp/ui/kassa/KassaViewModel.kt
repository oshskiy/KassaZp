package com.example.kassazp.ui.kassa

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kassazp.data.AppSettings
import com.example.kassazp.data.SettingsRepository
import com.example.kassazp.data.dao.KassaDraftDao
import com.example.kassazp.data.entity.KassaDraftEntity
import com.example.kassazp.utils.Calculator
import com.example.kassazp.utils.KassaResult
import com.example.kassazp.utils.KassaRow
import com.example.kassazp.utils.RowType
import com.example.kassazp.utils.Shift
import com.example.kassazp.utils.TextRecognizerHelper
import com.example.kassazp.utils.asRub
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class KassaRowUi(
    val id: Long,
    val amountText: String = "",
    val type: RowType = RowType.NORMAL
)

data class KassaUiState(
    val shift: Shift = Shift.DAY,
    val rows: List<KassaRowUi> = listOf(KassaRowUi(id = 0)),
    val result: KassaResult? = null,
    val isRecognizing: Boolean = false,
    val recognitionMessage: String? = null
)

class KassaViewModel(
    private val draftDao: KassaDraftDao,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(KassaUiState())
    val uiState: StateFlow<KassaUiState> = _uiState.asStateFlow()

    private var nextRowId = 1L
    private var currentSettings: AppSettings = AppSettings()

    init {
        viewModelScope.launch {
            currentSettings = settingsRepository.settingsFlow.first()
        }
        viewModelScope.launch {
            settingsRepository.settingsFlow.collect { currentSettings = it }
        }
        loadDraft()
    }

    private fun loadDraft() {
        viewModelScope.launch {
            val draft = draftDao.get()
            if (draft != null && draft.rowsSerialized.isNotBlank()) {
                val rows = draft.rowsSerialized.split(";").filter { it.isNotBlank() }.mapIndexed { idx, chunk ->
                    val parts = chunk.split(":")
                    val amount = parts.getOrNull(0) ?: ""
                    val typeLabel = parts.getOrNull(1) ?: RowType.NORMAL.label
                    KassaRowUi(id = idx.toLong(), amountText = amount, type = RowType.fromLabel(typeLabel))
                }
                nextRowId = rows.size.toLong()
                _uiState.value = _uiState.value.copy(
                    shift = Shift.fromLabel(draft.shift),
                    rows = rows.ifEmpty { listOf(KassaRowUi(id = 0)) }
                )
            }
        }
    }

    private fun persistDraft() {
        viewModelScope.launch {
            val state = _uiState.value
            val serialized = state.rows.joinToString(";") { "${it.amountText}:${it.type.label}" }
            draftDao.save(KassaDraftEntity(shift = state.shift.label, rowsSerialized = serialized))
        }
    }

    fun setShift(shift: Shift) {
        _uiState.value = _uiState.value.copy(shift = shift, result = null)
        persistDraft()
    }

    fun addRow() {
        val newRow = KassaRowUi(id = nextRowId++)
        _uiState.value = _uiState.value.copy(rows = _uiState.value.rows + newRow, result = null)
        persistDraft()
    }

    fun removeRow(id: Long) {
        val newRows = _uiState.value.rows.filterNot { it.id == id }
        _uiState.value = _uiState.value.copy(
            rows = newRows.ifEmpty { listOf(KassaRowUi(id = nextRowId++)) },
            result = null
        )
        persistDraft()
    }

    fun updateAmount(id: Long, amount: String) {
        val filtered = amount.filter { it.isDigit() || it == '.' || it == ',' }
        val rows = _uiState.value.rows.map { if (it.id == id) it.copy(amountText = filtered) else it }
        _uiState.value = _uiState.value.copy(rows = rows, result = null)
        persistDraft()
    }

    fun updateType(id: Long, type: RowType) {
        val rows = _uiState.value.rows.map { if (it.id == id) it.copy(type = type) else it }
        _uiState.value = _uiState.value.copy(rows = rows, result = null)
        persistDraft()
    }

    fun calculate() {
        val state = _uiState.value
        val validRows = state.rows.mapNotNull { row ->
            val amount = row.amountText.replace(",", ".").toDoubleOrNull()
            if (amount != null && amount > 0) KassaRow(amount, row.type) else null
        }
        val result = Calculator.calculate(
            rows = validRows,
            shift = state.shift,
            dayPercent = currentSettings.dayPercent,
            nightPercent = currentSettings.nightPercent,
            pdPercent = currentSettings.pdPercent,
            weldPercent = currentSettings.weldPercent
        )
        _uiState.value = state.copy(result = result)
    }

    fun reset() {
        nextRowId = 1L
        _uiState.value = KassaUiState()
        viewModelScope.launch { draftDao.clear() }
    }

    fun recognizePhoto(bitmap: Bitmap) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRecognizing = true, recognitionMessage = null)
            try {
                val text = TextRecognizerHelper.recognize(bitmap)
                val parsed = TextRecognizerHelper.parseAmountLines(text)
                if (parsed.isEmpty()) {
                    _uiState.value = _uiState.value.copy(
                        isRecognizing = false,
                        recognitionMessage = "Не удалось распознать суммы на фото. Попробуйте более чёткое фото или введите вручную."
                    )
                    return@launch
                }
                val existingNonEmpty = _uiState.value.rows.filter { it.amountText.isNotBlank() }
                val newRows = parsed.mapIndexed { idx, (amount, type) ->
                    KassaRowUi(id = nextRowId + idx, amountText = formatAmount(amount), type = type)
                }
                nextRowId += parsed.size
                _uiState.value = _uiState.value.copy(
                    rows = existingNonEmpty + newRows,
                    isRecognizing = false,
                    recognitionMessage = "Распознано строк: ${parsed.size}. Проверьте суммы перед расчётом."
                )
                persistDraft()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isRecognizing = false,
                    recognitionMessage = "Ошибка распознавания: ${e.message ?: "неизвестная ошибка"}"
                )
            }
        }
    }

    fun dismissRecognitionMessage() {
        _uiState.value = _uiState.value.copy(recognitionMessage = null)
    }

    private fun formatAmount(value: Double): String =
        if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()

    fun buildResultText(): String {
        val result = _uiState.value.result ?: return ""
        val sb = StringBuilder()
        sb.append("1. Касса: ${result.kassa.asRub()}\n")
        sb.append(
            "2. ЗП: ${result.zpNormal.asRub()} + ${result.zpSpecial.asRub()} = ${result.zpTotal.asRub()}\n"
        )
        var line = 3
        if (result.hasPackage) {
            sb.append("$line. Магазин: ${result.magazin.asRub()}\n")
            line++
        }
        sb.append("$line. Итог: ${result.itog.asRub()}")
        return sb.toString()
    }
}
