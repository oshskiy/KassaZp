package com.example.kassazp.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Destination(val route: String, val label: String, val icon: ImageVector) {
    data object Kassa : Destination("kassa", "Касса", Icons.Filled.Payments)
    data object Workers : Destination("workers", "Работники", Icons.Filled.Groups)
    data object Report : Destination("report", "Отчёт", Icons.Filled.BarChart)
    data object Settings : Destination("settings", "Настройки", Icons.Filled.Settings)

    companion object {
        val bottomItems = listOf(Kassa, Workers, Report, Settings)
    }
}

const val WORKER_DETAIL_ROUTE = "worker_detail/{workerId}"
fun workerDetailRoute(workerId: Long) = "worker_detail/$workerId"
