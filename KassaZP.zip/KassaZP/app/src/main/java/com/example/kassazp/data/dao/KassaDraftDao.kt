package com.example.kassazp.data.dao

import androidx.room.Dao
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import com.example.kassazp.data.entity.KassaDraftEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface KassaDraftDao {
    @Query("SELECT * FROM kassa_draft WHERE id = 1 LIMIT 1")
    fun observe(): Flow<KassaDraftEntity?>

    @Query("SELECT * FROM kassa_draft WHERE id = 1 LIMIT 1")
    suspend fun get(): KassaDraftEntity?

    @Upsert
    suspend fun save(draft: KassaDraftEntity)

    @Query("DELETE FROM kassa_draft WHERE id = 1")
    suspend fun clear()
}
