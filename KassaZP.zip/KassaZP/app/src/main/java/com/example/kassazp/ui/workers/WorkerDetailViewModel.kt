package com.example.kassazp.ui.workers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kassazp.data.dao.EarningDao
import com.example.kassazp.data.dao.WorkerDao
import com.example.kassazp.data.entity.EarningEntity
import com.example.kassazp.utils.Shift
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class EarningUi(
    val id: Long,
    val dateMillis: Long,
    val amount: Double,
    val shift: String
)

data class WorkerDetailUiState(
    val workerName: String = "",
    val entries: List<EarningUi> = emptyList(),
    val total: Double = 0.0
)

class WorkerDetailViewModel(
    private val workerDao: WorkerDao,
    private val earningDao: EarningDao,
    private val workerId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(WorkerDetailUiState())
    val uiState: StateFlow<WorkerDetailUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val worker = workerDao.findById(workerId)
            _uiState.value = _uiState.value.copy(workerName = worker?.name ?: "")
        }
        viewModelScope.launch {
            combine(
                earningDao.observeForWorker(workerId),
                earningDao.observeTotalForWorker(workerId)
            ) { entries, total ->
                WorkerDetailUiState(
                    workerName = _uiState.value.workerName,
                    entries = entries.map { EarningUi(it.id, it.dateMillis, it.amount, it.shift) },
                    total = total
                )
            }.collect { state ->
                _uiState.value = state.copy(workerName = _uiState.value.workerName.ifEmpty { state.workerName })
            }
        }
    }

    fun addEarning(dateMillis: Long, amount: Double, shift: Shift) {
        if (amount <= 0) return
        viewModelScope.launch {
            earningDao.insert(EarningEntity(workerId = workerId, dateMillis = dateMillis, amount = amount, shift = shift.label))
        }
    }

    fun updateEarning(id: Long, dateMillis: Long, amount: Double, shift: Shift) {
        viewModelScope.launch {
            earningDao.update(EarningEntity(id = id, workerId = workerId, dateMillis = dateMillis, amount = amount, shift = shift.label))
        }
    }

    fun deleteEarning(entry: EarningUi) {
        viewModelScope.launch {
            earningDao.delete(EarningEntity(id = entry.id, workerId = workerId, dateMillis = entry.dateMillis, amount = entry.amount, shift = entry.shift))
        }
    }
}
