package com.example.kassazp.utils

import kotlin.math.roundToLong

/** Форматирует сумму как целое число рублей с символом ₽, без десятичных знаков. */
fun Double.asRub(): String {
    val rounded = this.roundToLong()
    return "${rounded}₽"
}

fun Double.asRubSigned(): String {
    val rounded = this.roundToLong()
    val sign = if (rounded >= 0) "+" else ""
    return "$sign${rounded}₽"
}
