package com.example.kassazp.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.example.kassazp.KassaZPApp
import com.example.kassazp.navigation.Destination
import com.example.kassazp.navigation.WORKER_DETAIL_ROUTE
import com.example.kassazp.navigation.workerDetailRoute
import com.example.kassazp.ui.kassa.KassaScreen
import com.example.kassazp.ui.kassa.KassaViewModel
import com.example.kassazp.ui.report.ReportScreen
import com.example.kassazp.ui.report.ReportViewModel
import com.example.kassazp.ui.settings.SettingsScreen
import com.example.kassazp.ui.settings.SettingsViewModel
import com.example.kassazp.ui.workers.WorkerDetailScreen
import com.example.kassazp.ui.workers.WorkerDetailViewModel
import com.example.kassazp.ui.workers.WorkersScreen
import com.example.kassazp.ui.workers.WorkersViewModel

@Composable
fun MainScreen(app: KassaZPApp) {
    val navController = rememberNavController()
    val factory = ViewModelFactory(app)

    Scaffold(
        bottomBar = { AppBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Kassa.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Destination.Kassa.route) {
                val vm: KassaViewModel = viewModel(factory = factory)
                KassaScreen(vm)
            }
            composable(Destination.Workers.route) {
                val vm: WorkersViewModel = viewModel(factory = factory)
                WorkersScreen(vm, onWorkerClick = { id ->
                    navController.navigate(workerDetailRoute(id))
                })
            }
            composable(
                WORKER_DETAIL_ROUTE,
                arguments = listOf(navArgument("workerId") { type = NavType.LongType })
            ) { backStackEntry ->
                val workerId = backStackEntry.arguments?.getLong("workerId") ?: 0L
                val vm: WorkerDetailViewModel = viewModel(
                    factory = ViewModelFactory.forWorkerDetail(app, workerId)
                )
                WorkerDetailScreen(vm, onBack = { navController.popBackStack() })
            }
            composable(Destination.Report.route) {
                val vm: ReportViewModel = viewModel(factory = factory)
                ReportScreen(vm)
            }
            composable(Destination.Settings.route) {
                val vm: SettingsViewModel = viewModel(factory = factory)
                SettingsScreen(vm)
            }
        }
    }
}

@Composable
private fun AppBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    NavigationBar {
        Destination.bottomItems.forEach { destination ->
            NavigationBarItem(
                selected = currentRoute == destination.route,
                onClick = {
                    navController.navigate(destination.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(destination.icon, contentDescription = destination.label) },
                label = { Text(destination.label) }
            )
        }
    }
}
