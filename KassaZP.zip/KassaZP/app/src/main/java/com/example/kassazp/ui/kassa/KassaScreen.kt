package com.example.kassazp.ui.kassa

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import com.example.kassazp.utils.PdfExporter
import com.example.kassazp.utils.RowType
import com.example.kassazp.utils.Shift
import com.example.kassazp.utils.ShareUtils
import com.example.kassazp.utils.asRub

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KassaScreen(viewModel: KassaViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var pendingPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val bitmap = uriToBitmap(context, it)
            bitmap?.let { bmp -> viewModel.recognizePhoto(bmp) }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        bitmap?.let { viewModel.recognizePhoto(it) }
    }

    state.recognitionMessage?.let { msg ->
        LaunchedEffect(msg) {
            // Показ через Snackbar ниже
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(state.recognitionMessage) {
        state.recognitionMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissRecognitionMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Касса", style = MaterialTheme.typography.headlineMedium)
            }

            item {
                ShiftSelector(
                    shift = state.shift,
                    onShiftChange = viewModel::setShift
                )
            }

            items(state.rows, key = { it.id }) { row ->
                KassaRowItem(
                    row = row,
                    canRemove = state.rows.size > 1,
                    onAmountChange = { viewModel.updateAmount(row.id, it) },
                    onTypeChange = { viewModel.updateType(row.id, it) },
                    onRemove = { viewModel.removeRow(row.id) }
                )
            }

            item {
                OutlinedButton(
                    onClick = viewModel::addRow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Добавить строку")
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { cameraLauncher.launch(null) },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isRecognizing
                    ) {
                        Icon(Icons.Filled.CameraAlt, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text(if (state.isRecognizing) "Распознаю…" else "Фото")
                    }
                    OutlinedButton(
                        onClick = { galleryLauncher.launch("image/*") },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isRecognizing
                    ) {
                        Text("Галерея")
                    }
                }
            }

            item {
                Button(
                    onClick = viewModel::calculate,
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Рассчитать", style = MaterialTheme.typography.titleMedium)
                }
            }

            item {
                OutlinedButton(
                    onClick = viewModel::reset,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Сбросить")
                }
            }

            state.result?.let { result ->
                item {
                    ResultCard(resultText = viewModel.buildResultText())
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Касса", viewModel.buildResultText()))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = null)
                        }
                        OutlinedButton(
                            onClick = { ShareUtils.shareText(context, viewModel.buildResultText()) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null)
                        }
                        OutlinedButton(
                            onClick = {
                                val uri = PdfExporter.exportLines(
                                    context,
                                    "Расчёт кассы",
                                    viewModel.buildResultText().split("\n"),
                                    "kassa_${System.currentTimeMillis()}.pdf"
                                )
                                ShareUtils.shareFile(context, uri, "application/pdf")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = null)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun ShiftSelector(shift: Shift, onShiftChange: (Shift) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Shift.entries.forEach { s ->
            val selected = s == shift
            FilterChip(
                selected = selected,
                onClick = { onShiftChange(s) },
                label = { Text(s.label, style = MaterialTheme.typography.titleMedium) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KassaRowItem(
    row: KassaRowUi,
    canRemove: Boolean,
    onAmountChange: (String) -> Unit,
    onTypeChange: (RowType) -> Unit,
    onRemove: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = row.amountText,
                onValueChange = onAmountChange,
                label = { Text("Сумма") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f),
                singleLine = true
            )

            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = it },
                modifier = Modifier.weight(1f)
            ) {
                OutlinedTextField(
                    value = row.type.label,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Тип") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    RowType.entries.forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type.label) },
                            onClick = { onTypeChange(type); expanded = false }
                        )
                    }
                }
            }

            if (canRemove) {
                IconButton(onClick = onRemove) {
                    Icon(Icons.Filled.Close, contentDescription = "Удалить строку")
                }
            }
        }
    }
}

@Composable
private fun ResultCard(resultText: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            resultText.split("\n").forEach { line ->
                Text(
                    text = line,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
    }
}

private fun uriToBitmap(context: Context, uri: Uri): Bitmap? = try {
    context.contentResolver.openInputStream(uri)?.use { input ->
        android.graphics.BitmapFactory.decodeStream(input)
    }
} catch (e: Exception) {
    null
}
