package com.example.kassazp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.kassazp.data.AppSettings
import com.example.kassazp.ui.MainScreen
import com.example.kassazp.ui.settings.PinLockScreen
import com.example.kassazp.ui.theme.KassaZPTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as KassaZPApp

        setContent {
            KassaZPTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(app)
                }
            }
        }
    }
}

@Composable
private fun AppRoot(app: KassaZPApp) {
    val settings by app.settingsRepository.settingsFlow.collectAsState(initial = AppSettings())
    var unlocked by remember(settings.pinEnabled) { mutableStateOf(!settings.pinEnabled) }

    Box(modifier = Modifier.fillMaxSize()) {
        if (unlocked) {
            MainScreen(app)
        } else {
            PinLockScreen(correctPin = settings.pin, onUnlocked = { unlocked = true })
        }
    }
}
