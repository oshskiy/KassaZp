package com.example.kassazp.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.kassazp.KassaZPApp
import com.example.kassazp.ui.kassa.KassaViewModel
import com.example.kassazp.ui.report.ReportViewModel
import com.example.kassazp.ui.settings.SettingsViewModel
import com.example.kassazp.ui.workers.WorkerDetailViewModel
import com.example.kassazp.ui.workers.WorkersViewModel

class ViewModelFactory(private val app: KassaZPApp) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val db = app.database
        val settings = app.settingsRepository
        @Suppress("UNCHECKED_CAST")
        return when (modelClass) {
            KassaViewModel::class.java -> KassaViewModel(db.kassaDraftDao(), settings) as T
            WorkersViewModel::class.java -> WorkersViewModel(db.workerDao(), db.earningDao()) as T
            ReportViewModel::class.java -> ReportViewModel(db.workerDao(), db.earningDao()) as T
            SettingsViewModel::class.java -> SettingsViewModel(settings) as T
            else -> throw IllegalArgumentException("Unknown ViewModel: $modelClass")
        }
    }

    companion object {
        fun forWorkerDetail(app: KassaZPApp, workerId: Long): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    @Suppress("UNCHECKED_CAST")
                    return WorkerDetailViewModel(app.database.workerDao(), app.database.earningDao(), workerId) as T
                }
            }
    }
}
