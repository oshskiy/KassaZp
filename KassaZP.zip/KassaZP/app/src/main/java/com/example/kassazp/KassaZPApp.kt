package com.example.kassazp

import android.app.Application
import com.example.kassazp.data.AppDatabase
import com.example.kassazp.data.SettingsRepository

class KassaZPApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
}
