package com.example.kassazp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class PieSlice(val label: String, val value: Double, val color: Color)

private val palette = listOf(
    Color(0xFFFF7A00), Color(0xFF2E7D32), Color(0xFF1565C0),
    Color(0xFFC62828), Color(0xFF6A1B9A), Color(0xFFF9A825),
    Color(0xFF00838F), Color(0xFF5D4037)
)

fun buildPieSlices(entries: List<Pair<String, Double>>): List<PieSlice> =
    entries.mapIndexed { index, (label, value) ->
        PieSlice(label, value, palette[index % palette.size])
    }

@Composable
fun PieChart(slices: List<PieSlice>, modifier: Modifier = Modifier) {
    val total = slices.sumOf { it.value }
    Column(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .padding(16.dp)
        ) {
            var startAngle = -90f
            if (total > 0) {
                slices.forEach { slice ->
                    val sweep = (slice.value / total * 360f).toFloat()
                    drawArc(
                        color = slice.color,
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = true
                    )
                    startAngle += sweep
                }
            }
        }
        slices.forEach { slice ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(slice.color)
                )
                Text(
                    text = "  ${slice.label}: ${if (total > 0) (slice.value / total * 100).toInt() else 0}%",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
