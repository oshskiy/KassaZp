package com.example.kassazp.ui.workers

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kassazp.data.dao.EarningDao
import com.example.kassazp.data.dao.WorkerDao
import com.example.kassazp.data.entity.WorkerEntity
import com.example.kassazp.utils.TextRecognizerHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WorkerUi(
    val id: Long,
    val name: String,
    val total: Double
)

data class WorkersUiState(
    val workers: List<WorkerUi> = emptyList(),
    val isRecognizing: Boolean = false,
    val recognitionMessage: String? = null,
    val pendingNamesToConfirm: List<String> = emptyList()
)

class WorkersViewModel(
    private val workerDao: WorkerDao,
    private val earningDao: EarningDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(WorkersUiState())
    val uiState: StateFlow<WorkersUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            workerDao.observeAll().flatMapLatest { workers ->
                if (workers.isEmpty()) {
                    kotlinx.coroutines.flow.flowOf(emptyList<WorkerUi>())
                } else {
                    val totalFlows = workers.map { w ->
                        earningDao.observeTotalForWorker(w.id).map { total -> WorkerUi(w.id, w.name, total) }
                    }
                    combine(totalFlows) { it.toList().sortedByDescending { w -> w.total } }
                }
            }.collect { list ->
                _uiState.value = _uiState.value.copy(workers = list)
            }
        }
    }

    fun addWorker(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            val existing = workerDao.findByName(trimmed)
            if (existing == null) {
                workerDao.insert(WorkerEntity(name = trimmed))
            }
        }
    }

    fun recognizeShiftPhoto(bitmap: Bitmap) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRecognizing = true, recognitionMessage = null)
            try {
                val text = TextRecognizerHelper.recognize(bitmap)
                val names = TextRecognizerHelper.parseNames(text)
                if (names.isEmpty()) {
                    _uiState.value = _uiState.value.copy(
                        isRecognizing = false,
                        recognitionMessage = "Имена на фото не распознаны. Попробуйте более чёткое фото."
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isRecognizing = false,
                        pendingNamesToConfirm = names,
                        recognitionMessage = "Распознано имён: ${names.size}. Подтвердите список ниже."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isRecognizing = false,
                    recognitionMessage = "Ошибка распознавания: ${e.message ?: "неизвестная ошибка"}"
                )
            }
        }
    }

    fun confirmPendingNames(selected: List<String>) {
        viewModelScope.launch {
            selected.forEach { addWorker(it) }
            _uiState.value = _uiState.value.copy(pendingNamesToConfirm = emptyList())
        }
    }

    fun discardPendingNames() {
        _uiState.value = _uiState.value.copy(pendingNamesToConfirm = emptyList())
    }

    fun dismissMessage() {
        _uiState.value = _uiState.value.copy(recognitionMessage = null)
    }
}
