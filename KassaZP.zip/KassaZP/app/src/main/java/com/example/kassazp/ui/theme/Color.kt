package com.example.kassazp.ui.theme

import androidx.compose.ui.graphics.Color

val OrangePrimary = Color(0xFFFF7A00)
val OrangePrimaryDark = Color(0xFFCC6200)
val DarkSurface = Color(0xFF1B1B1F)
val LightSurface = Color(0xFFFFFBFE)
val GreenPositive = Color(0xFF2E7D32)
val RedNegative = Color(0xFFC62828)
