package com.example.kassazp.utils

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Обёртка над ML Kit Text Recognition (офлайн, работает без интернета —
 * модель "latin" ML Kit понимает и кириллицу для базового распознавания цифр/слов
 * в большинстве случаев, так как используется общий текстовый детектор).
 *
 * ОГРАНИЧЕНИЕ: качество распознавания сильно зависит от почерка и освещения.
 * Плохой рукописный текст может распознаваться с ошибками — приложение
 * всегда показывает результат пользователю для проверки перед сохранением,
 * так как ML Kit "latin" оптимизирован под печатный и разборчивый рукописный текст.
 */
object TextRecognizerHelper {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                if (cont.isActive) cont.resume(visionText.text)
            }
            .addOnFailureListener { e ->
                if (cont.isActive) cont.resumeWithException(e)
            }
    }

    /**
     * Извлекает суммы и, если рядом есть пометка (ПД / Сварка / ПК), тип строки.
     * Работает построчно: ищет число в строке и ключевые слова рядом.
     */
    fun parseAmountLines(rawText: String): List<Pair<Double, RowType>> {
        val results = mutableListOf<Pair<Double, RowType>>()
        val numberRegex = Regex("""\d[\d\s]*[.,]?\d*""")

        rawText.lines().forEach { line ->
            val cleanLine = line.trim()
            if (cleanLine.isEmpty()) return@forEach

            val match = numberRegex.find(cleanLine) ?: return@forEach
            val numStr = match.value.replace(" ", "").replace(",", ".")
            val amount = numStr.toDoubleOrNull() ?: return@forEach
            if (amount <= 0) return@forEach

            val lower = cleanLine.lowercase()
            val type = when {
                lower.contains("пд") -> RowType.PD
                lower.contains("сварк") -> RowType.WELD
                lower.contains("пк") || lower.contains("пакет") || lower.contains("магазин") -> RowType.PACKAGE
                else -> RowType.NORMAL
            }
            results.add(amount to type)
        }
        return results
    }

    /**
     * Извлекает вероятные имена (слова с заглавной буквы, длиной от 3 символов,
     * без цифр) — используется при распознавании списка работников со смены.
     */
    fun parseNames(rawText: String): List<String> {
        val nameRegex = Regex("""[А-ЯЁA-Z][а-яёa-z]{2,}""")
        return nameRegex.findAll(rawText)
            .map { it.value }
            .distinct()
            .toList()
    }
}
