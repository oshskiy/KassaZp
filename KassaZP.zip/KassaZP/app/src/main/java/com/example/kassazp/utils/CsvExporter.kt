package com.example.kassazp.utils

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

data class CsvRow(
    val name: String,
    val month: String,
    val amount: Double,
    val day: Double,
    val night: Double
)

object CsvExporter {

    fun export(context: Context, rows: List<CsvRow>, fileName: String): Uri {
        val sb = StringBuilder()
        sb.append("Имя;Месяц;Сумма;День;Ночь\n")
        rows.forEach { r ->
            sb.append("${r.name};${r.month};${r.amount};${r.day};${r.night}\n")
        }

        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, fileName)
        FileOutputStream(file).use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }

        return FileProvider.getUriForFile(context, "com.example.kassazp.fileprovider", file)
    }
}
