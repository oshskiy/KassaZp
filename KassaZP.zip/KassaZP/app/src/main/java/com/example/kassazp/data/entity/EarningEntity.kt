package com.example.kassazp.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Одна запись заработка работника за конкретный день/смену.
 */
@Entity(
    tableName = "earnings",
    foreignKeys = [
        ForeignKey(
            entity = WorkerEntity::class,
            parentColumns = ["id"],
            childColumns = ["workerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("workerId")]
)
data class EarningEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: Long,
    val dateMillis: Long,
    val amount: Double,
    val shift: String // "День" или "Ночь"
)
