package com.example.kassazp.data.dao

import androidx.room.*
import com.example.kassazp.data.entity.WorkerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkerDao {
    @Query("SELECT * FROM workers ORDER BY name ASC")
    fun observeAll(): Flow<List<WorkerEntity>>

    @Query("SELECT * FROM workers WHERE name = :name LIMIT 1")
    suspend fun findByName(name: String): WorkerEntity?

    @Query("SELECT * FROM workers WHERE id = :id LIMIT 1")
    suspend fun findById(id: Long): WorkerEntity?

    @Insert
    suspend fun insert(worker: WorkerEntity): Long

    @Update
    suspend fun update(worker: WorkerEntity)

    @Delete
    suspend fun delete(worker: WorkerEntity)
}
