package com.example.kassazp.utils

import kotlin.math.floor
import kotlin.math.roundToInt

enum class RowType(val label: String) {
    NORMAL("Обычная"),
    PD("ПД"),
    WELD("Сварка"),
    PACKAGE("ПК");

    companion object {
        fun fromLabel(label: String): RowType =
            entries.firstOrNull { it.label == label } ?: NORMAL
    }
}

enum class Shift(val label: String) {
    DAY("День"),
    NIGHT("Ночь");

    companion object {
        fun fromLabel(label: String): Shift =
            entries.firstOrNull { it.label == label } ?: DAY
    }
}

data class KassaRow(
    val amount: Double,
    val type: RowType
)

data class KassaResult(
    val kassa: Double,
    val zpNormal: Double,   // ЗП с обычной кассы (день/ночь %)
    val zpSpecial: Double,  // ЗП с ПД+Сварка (%)
    val zpTotal: Double,    // округлённая до 10 сумма зарплаты
    val magazin: Double,    // сумма ПК, если есть
    val hasPackage: Boolean,
    val itog: Double
)

object Calculator {

    /**
     * Округление до 10 рублей:
     * последняя цифра 5 и больше -> вверх, 4 и меньше -> вниз.
     */
    fun roundToTen(value: Double): Double {
        val base = floor(value / 10.0) * 10.0
        val remainder = value - base
        return if (remainder >= 5.0) base + 10.0 else base
    }

    fun calculate(
        rows: List<KassaRow>,
        shift: Shift,
        dayPercent: Double,
        nightPercent: Double,
        pdPercent: Double,
        weldPercent: Double
    ): KassaResult {
        val normalSum = rows.filter { it.type == RowType.NORMAL }.sumOf { it.amount }
        val pdSum = rows.filter { it.type == RowType.PD }.sumOf { it.amount }
        val weldSum = rows.filter { it.type == RowType.WELD }.sumOf { it.amount }
        val packageSum = rows.filter { it.type == RowType.PACKAGE }.sumOf { it.amount }

        val kassa = normalSum + pdSum + weldSum + packageSum

        val shiftPercent = if (shift == Shift.DAY) dayPercent else nightPercent
        val zpNormalRaw = normalSum * (shiftPercent / 100.0)
        val zpSpecialRaw = pdSum * (pdPercent / 100.0) + weldSum * (weldPercent / 100.0)

        val zpTotalRaw = zpNormalRaw + zpSpecialRaw
        val zpTotal = roundToTen(zpTotalRaw)

        // Распределяем округлённую ЗП пропорционально между "обычной" и "спец" частями,
        // но по требованию формата выводим их как рассчитанные до округления доли,
        // а итоговая сумма (после "+") — округлённый итог.
        val itog = kassa - zpTotal

        return KassaResult(
            kassa = kassa,
            zpNormal = zpNormalRaw,
            zpSpecial = zpSpecialRaw,
            zpTotal = zpTotal,
            magazin = packageSum,
            hasPackage = packageSum > 0.0,
            itog = itog
        )
    }
}
