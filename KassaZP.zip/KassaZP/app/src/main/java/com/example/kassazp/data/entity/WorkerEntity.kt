package com.example.kassazp.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Работник шиномонтажа. Накопительная сумма считается на лету из EarningEntity,
 * здесь хранится только имя и служебные поля.
 */
@Entity(tableName = "workers")
data class WorkerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)
