package com.example.kassazp.data.dao

import androidx.room.*
import com.example.kassazp.data.entity.EarningEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface EarningDao {
    @Query("SELECT * FROM earnings WHERE workerId = :workerId ORDER BY dateMillis DESC")
    fun observeForWorker(workerId: Long): Flow<List<EarningEntity>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM earnings WHERE workerId = :workerId")
    fun observeTotalForWorker(workerId: Long): Flow<Double>

    @Query(
        "SELECT * FROM earnings WHERE dateMillis BETWEEN :start AND :end ORDER BY dateMillis DESC"
    )
    fun observeForPeriod(start: Long, end: Long): Flow<List<EarningEntity>>

    @Query(
        "SELECT * FROM earnings WHERE dateMillis BETWEEN :start AND :end ORDER BY dateMillis DESC"
    )
    suspend fun getForPeriod(start: Long, end: Long): List<EarningEntity>

    @Insert
    suspend fun insert(earning: EarningEntity): Long

    @Update
    suspend fun update(earning: EarningEntity)

    @Delete
    suspend fun delete(earning: EarningEntity)
}
