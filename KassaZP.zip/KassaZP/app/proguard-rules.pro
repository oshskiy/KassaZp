# Add project specific ProGuard rules here.
-keep class com.example.kassazp.data.entity.** { *; }
